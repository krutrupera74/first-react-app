import React from 'react';
import './Post.css';

const post = (props) => (
    <article className='Post'>
        <h1>
            <div className='Info'>
                <div className='Author'>
                    Author
                </div>
            </div>
        </h1>
    </article>
)

export default post;